﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Healthpack : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

    function OnTriggerEnter2D ()
    {
        if (life >= 80)
        {
            life = 100;
        }
        else
        {
            Script.life += 20;
        }
        print("Gained 20 health");
        Destroy(gameObject);

    }

    
    // Update is called once per frame
    void Update () {
		
	}
}
*/